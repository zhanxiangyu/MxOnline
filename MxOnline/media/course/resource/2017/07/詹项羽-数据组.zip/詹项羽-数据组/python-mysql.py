# -*- coding:utf-8 -*-
# __author__ = 'zhan'

import MySQLdb
conn = MySQLdb.connect(
    host='localhost',
    user='root',
    passwd='zhan',
    db='sys',
    charset='utf8',
)

cursor=conn.cursor()
sql = """
    create table `jingdong_xiaomi6_pinglun_sql` (
  `id` int primary key auto_increment COMMENT 'id',
  `nickname` varchar(20)  DEFAULT NULL COMMENT '购买用户',
  `productColor` varchar(20)  DEFAULT NULL COMMENT '购买手机颜色',
  `productSize` varchar(20)  DEFAULT NULL COMMENT '购买手机大小',
  `referenceTime` varchar(20)  DEFAULT NULL COMMENT '购买时间',
  `creationTime` varchar(20)  DEFAULT NULL COMMENT '评论时间',
  `comment` text  DEFAULT NULL COMMENT '评论内容',
   UNIQUE KEY `myurl_UNIQUE` (`nickname`,`productSize`,`referenceTime`,`creationTime`,`productColor`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='小米6手机评论';

"""
cursor.execute("DROP TABLE IF EXISTS jingdong_xiaomi6_pinglun_sql;")
cursor.execute(sql)

result = cursor.execute("""
                    insert ignore into jingdong_xiaomi6_pinglun_sql(
                                    nickname,
                                    productColor,
                                    productSize,
                                    referenceTime,
                                    creationTime,
                                    comment)
                              VALUES(%s,%s,%s,%s,%s,%s);
                                      """, ('zhan','红色','6GB 128GB','2017.06.28','2017.06.30','good 好用'))
if result:
    print '添加成功'
else:
    print '重复添加'

cursor.execute("update jingdong_xiaomi6_pinglun_sql set productColor='%s' where nickname = 'zhan'"%'黑色')
print '修改成功'
aa = cursor.execute('select * from jingdong_xiaomi6_pinglun_sql')
info = cursor.fetchmany(aa)
for ii in info:
    print '查询',ii

cursor.close()
conn.commit()
conn.close()