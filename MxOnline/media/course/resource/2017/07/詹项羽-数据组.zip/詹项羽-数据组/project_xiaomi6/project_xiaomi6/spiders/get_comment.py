# -*- coding:utf-8 -*-
# __author__ = 'zhan'
# __date__ = '17-6-27 下午4:27'
import scrapy
import json
from project_xiaomi6.items import ProjectXiaomi6Item
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

# 'https://item.jd.com/4099139.html'
class XiaoMi6Spider(scrapy.Spider):
    name = "xiaomi6"

    def __init__(self, ):
        super(XiaoMi6Spider, self).__init__()
        self.allowed_domains = ["https://item.jd.com"]
        self.start_urls = [
            'https://sclub.jd.com/comment/productPageComments.action?callback=fetchJSON_comment98vv46878&productId=4099139&score=0&sortType=5&page=0&pageSize=10&isShadowSku=0&fold=1'
        ]


    def parse(self, response):
        text_json = response.text.replace(']});', ']}').replace('fetchJSON_comment98vv46878(', '')
        try:
            r = json.loads(text_json)
        except:
            a_href = response.url
            yield scrapy.Request(url=a_href, dont_filter=True, callback=self.parse)
            return

        maxPage = r['maxPage']
        maxPage = int(maxPage)
        for i in range(maxPage):
            url = 'https://sclub.jd.com/comment/productPageComments.action?callback=fetchJSON_comment98vv46878&productId=4099139&score=0&sortType=5&page={}&pageSize=10&isShadowSku=0&fold=1'.format(i)
            yield scrapy.Request(url=url, dont_filter=True, callback=self.get_next, meta={'url_right': url})

    def get_next(self, response):
        text_json = response.text.replace(']});',']}').replace('fetchJSON_comment98vv46878(', '')
        try:
            r = json.loads(text_json)
        except:
            url = response.meta.get('url_right', "")
            yield scrapy.Request(url=url, dont_filter=True, callback=self.get_next)
            return

        for i in range(len(r['comments'])):
            comment = r['comments'][i]['content']
            creationTime = r['comments'][i]['creationTime']
            productColor = r['comments'][i]['productColor']
            productSize = r['comments'][i]['productSize']
            referenceTime = r['comments'][i]['referenceTime']
            nickname = r['comments'][i]['nickname']

            item = ProjectXiaomi6Item()
            item['comment'] = "".join(comment).encode('utf-8').strip()
            item['creationTime'] = "".join(creationTime).encode('utf-8').strip()
            item['productColor'] = "".join(productColor).encode('utf-8').strip()
            item['productSize'] = "".join(productSize).encode('utf-8').strip()
            item['referenceTime'] = "".join(referenceTime).encode('utf-8').strip()
            item['nickname'] = "".join(nickname).encode('utf-8').strip()
            yield item


