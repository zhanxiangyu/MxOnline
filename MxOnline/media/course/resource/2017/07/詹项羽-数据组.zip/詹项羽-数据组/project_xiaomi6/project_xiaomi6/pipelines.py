# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

import MySQLdb
from twisted.enterprise import adbapi
import MySQLdb.cursors

class ProjectXiaomi6Pipeline(object):
    def __init__(self, dbpool):
        self.dbpool = dbpool

    @classmethod
    def from_settings(cls, settings):
        dbargs = dict(
            host=settings['MYSQL_HOST'],
            db=settings['MYSQL_DBNAME'],
            port=settings['MYSQL_PORT'],
            user=settings['MYSQL_USER'],
            passwd=settings['MYSQL_PASSWD'],
            charset='utf8',
            cursorclass=MySQLdb.cursors.DictCursor,
            use_unicode=True,
        )
        dbpool = adbapi.ConnectionPool('MySQLdb', **dbargs)
        return cls(dbpool)

    def process_item(self, item, spider):
        d = self.dbpool.runInteraction(self._do_upinsert, item, spider)
        # d2 = self.dbpool.runInteraction(self._update_national_data, item, spider)
        # return item

    def _do_upinsert(self, conn, item, spider):
        valid = True
        for data in item:
            if not data:
                valid = False
                print 'NOT ANY DATA IN ITEM'  # tianxiao code
        if valid:
            result = conn.execute("""
                    insert ignore into jingdong_xiaomi6_pinglun(
                                    nickname,
                                    productColor,
                                    productSize,
                                    referenceTime,
                                    creationTime,
                                    comment)
                              VALUES(%s,%s,%s,%s,%s,%s);
                                      """, (
                item['nickname'],
                item['productColor'],
                item['productSize'],
                item['referenceTime'],
                item['creationTime'],
                item['comment']))
            if result:
                print 'added a record'
            else:
                print 'failed insert into table land_mortgage'