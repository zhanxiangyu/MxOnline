# -*- coding: utf-8 -*-

#服务器端
from socket import *
server = socket(AF_INET, SOCK_STREAM)
addr = ('localhost',1024)
server.bind(addr)
server.listen(1)
while True:
    client, addr_client  = server.accept()
    b = client.recv(1024)
    print b
    client.close()