# -*- coding: utf-8 -*-

#socket通信客户端
from socket import *
client = socket(AF_INET,SOCK_STREAM)
ad=('localhost',1024)
client.connect(ad)
client.send('hello world !!!')
client.close()