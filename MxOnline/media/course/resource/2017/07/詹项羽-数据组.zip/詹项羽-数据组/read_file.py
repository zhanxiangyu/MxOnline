#coding:utf-8
#__author__ = 'zhan'
import os

base_dir = os.path.dirname(os.path.abspath(__file__))
get_path = os.path.join(base_dir, 'record.txt')
print u'文件路径：', get_path


dic = {}
list_dic = []
f = open('%s'%get_path, 'r')
for line in f.readlines():
    get_line = line.strip()
    if not len(line):
        continue

    lista = get_line.split(',')
    if lista[1].strip() == 'age':
        continue
    list_dic.append({'name':lista[0].strip(), 'age':lista[1].strip(), 'score':lista[2].strip()})


for list_i in list_dic:
    print list_i

count = 0
list_score = []
list_name = []
for ii in list_dic:
    if int(ii['score']) < 60:
        list_score.append(ii['name'])
    if ii['name'].startswith('L'):
        list_name.append(ii['name'])

    count += int(ii['score'])
print u'得分低于60的人:', list_score
print u'名字以L开头的人: ', list_name
print u'所有人的总分是:', count
